CREATE TABLE "Players" (
	"id" VARCHAR(255) NOT NULL,
	"Last" VARCHAR(255) NOT NULL,
	"First" VARCHAR(255) NOT NULL,
	"Position" integer NOT NULL
) WITH (
  OIDS=FALSE
);



CREATE TABLE "Positions" (
	"Position" integer NOT NULL
) WITH (
  OIDS=FALSE
);



CREATE TABLE "Team Location" (
	"team_id" VARCHAR(255) NOT NULL,
	"league" VARCHAR(255) NOT NULL,
	"city" VARCHAR(255) NOT NULL,
	"franch_id" VARCHAR(255) NOT NULL,
	CONSTRAINT Team Location_pk PRIMARY KEY ("team_id")
) WITH (
  OIDS=FALSE
);



CREATE TABLE "Team Nickname" (
	"nickname" VARCHAR(255) NOT NULL,
	"franch_id" VARCHAR(255) NOT NULL
) WITH (
  OIDS=FALSE
);



CREATE TABLE "Park Location" (
	"park_id" VARCHAR(255) NOT NULL,
	"city" VARCHAR(255) NOT NULL,
	"state" VARCHAR(255) NOT NULL
) WITH (
  OIDS=FALSE
);



CREATE TABLE "Park Info" (
	"park_id" VARCHAR(255) NOT NULL,
	"name" VARCHAR(255) NOT NULL,
	"league" VARCHAR(255) NOT NULL
) WITH (
  OIDS=FALSE
);



CREATE TABLE "Visitors" (
	"game_id" VARCHAR(255) NOT NULL,
	"V1" VARCHAR(255) NOT NULL,
	"V2" VARCHAR(255) NOT NULL,
	"V3" VARCHAR(255) NOT NULL,
	"V4" VARCHAR(255) NOT NULL,
	"V5" VARCHAR(255) NOT NULL,
	"V6" VARCHAR(255) NOT NULL,
	"V7" VARCHAR(255) NOT NULL,
	"V8" VARCHAR(255) NOT NULL,
	"V9" VARCHAR(255) NOT NULL,
	CONSTRAINT Visitors_pk PRIMARY KEY ("game_id")
) WITH (
  OIDS=FALSE
);



CREATE TABLE "Games" (
	"game_id" VARCHAR(255) NOT NULL,
	"v_name" VARCHAR(255) NOT NULL,
	"h_name" VARCHAR(255) NOT NULL,
	"v_score" VARCHAR(255) NOT NULL,
	"h_score" VARCHAR(255) NOT NULL,
	"park_id" VARCHAR(255) NOT NULL,
	"h_manager" VARCHAR(255) NOT NULL,
	"v_manager" VARCHAR(255) NOT NULL,
	CONSTRAINT Games_pk PRIMARY KEY ("game_id")
) WITH (
  OIDS=FALSE
);



CREATE TABLE "Home" (
	"game_id" VARCHAR(255) NOT NULL,
	"H1" VARCHAR(255) NOT NULL,
	"H2" VARCHAR(255) NOT NULL,
	"H3" VARCHAR(255) NOT NULL,
	"H4" VARCHAR(255) NOT NULL,
	"H5" VARCHAR(255) NOT NULL,
	"H6" VARCHAR(255) NOT NULL,
	"H7" VARCHAR(255) NOT NULL,
	"H8" VARCHAR(255) NOT NULL,
	"H9" VARCHAR(255) NOT NULL,
	CONSTRAINT Home_pk PRIMARY KEY ("game_id")
) WITH (
  OIDS=FALSE
);



CREATE TABLE "Umpires Info" (
	"id" VARCHAR(255) NOT NULL,
	"Name" VARCHAR(255) NOT NULL
) WITH (
  OIDS=FALSE
);



CREATE TABLE "Umpires" (
	"game_id" VARCHAR(255) NOT NULL,
	"hp_umpire" VARCHAR(255) NOT NULL,
	"1b_umpire" VARCHAR(255) NOT NULL,
	"2b_umpire" VARCHAR(255) NOT NULL,
	"3b_umpire" VARCHAR(255) NOT NULL,
	"lf_umpire" VARCHAR(255) NOT NULL,
	"rf_umpire" VARCHAR(255) NOT NULL
) WITH (
  OIDS=FALSE
);



ALTER TABLE "Players" ADD CONSTRAINT "Players_fk0" FOREIGN KEY ("Position") REFERENCES "Positions"("Position");



ALTER TABLE "Team Nickname" ADD CONSTRAINT "Team Nickname_fk0" FOREIGN KEY ("franch_id") REFERENCES "Team Location"("franch_id");


ALTER TABLE "Park Info" ADD CONSTRAINT "Park Info_fk0" FOREIGN KEY ("park_id") REFERENCES "Park Location"("park_id");

ALTER TABLE "Visitors" ADD CONSTRAINT "Visitors_fk0" FOREIGN KEY ("game_id") REFERENCES "Games"("game_id");
ALTER TABLE "Visitors" ADD CONSTRAINT "Visitors_fk1" FOREIGN KEY ("V1") REFERENCES "Players"("id");
ALTER TABLE "Visitors" ADD CONSTRAINT "Visitors_fk2" FOREIGN KEY ("V2") REFERENCES "Players"("id");
ALTER TABLE "Visitors" ADD CONSTRAINT "Visitors_fk3" FOREIGN KEY ("V3") REFERENCES "Players"("id");
ALTER TABLE "Visitors" ADD CONSTRAINT "Visitors_fk4" FOREIGN KEY ("V4") REFERENCES "Players"("id");
ALTER TABLE "Visitors" ADD CONSTRAINT "Visitors_fk5" FOREIGN KEY ("V5") REFERENCES "Players"("id");
ALTER TABLE "Visitors" ADD CONSTRAINT "Visitors_fk6" FOREIGN KEY ("V6") REFERENCES "Players"("id");
ALTER TABLE "Visitors" ADD CONSTRAINT "Visitors_fk7" FOREIGN KEY ("V7") REFERENCES "Players"("id");
ALTER TABLE "Visitors" ADD CONSTRAINT "Visitors_fk8" FOREIGN KEY ("V8") REFERENCES "Players"("id");
ALTER TABLE "Visitors" ADD CONSTRAINT "Visitors_fk9" FOREIGN KEY ("V9") REFERENCES "Players"("id");

ALTER TABLE "Games" ADD CONSTRAINT "Games_fk0" FOREIGN KEY ("v_name") REFERENCES "Team Location"("team_id");
ALTER TABLE "Games" ADD CONSTRAINT "Games_fk1" FOREIGN KEY ("park_id") REFERENCES "Park Info"("park_id");

ALTER TABLE "Home" ADD CONSTRAINT "Home_fk0" FOREIGN KEY ("game_id") REFERENCES "Games"("game_id");
ALTER TABLE "Home" ADD CONSTRAINT "Home_fk1" FOREIGN KEY ("H1") REFERENCES "Players"("id");
ALTER TABLE "Home" ADD CONSTRAINT "Home_fk2" FOREIGN KEY ("H2") REFERENCES "Players"("id");
ALTER TABLE "Home" ADD CONSTRAINT "Home_fk3" FOREIGN KEY ("H3") REFERENCES "Players"("id");
ALTER TABLE "Home" ADD CONSTRAINT "Home_fk4" FOREIGN KEY ("H4") REFERENCES "Players"("id");
ALTER TABLE "Home" ADD CONSTRAINT "Home_fk5" FOREIGN KEY ("H5") REFERENCES "Players"("id");
ALTER TABLE "Home" ADD CONSTRAINT "Home_fk6" FOREIGN KEY ("H6") REFERENCES "Players"("id");
ALTER TABLE "Home" ADD CONSTRAINT "Home_fk7" FOREIGN KEY ("H7") REFERENCES "Players"("id");
ALTER TABLE "Home" ADD CONSTRAINT "Home_fk8" FOREIGN KEY ("H8") REFERENCES "Players"("id");
ALTER TABLE "Home" ADD CONSTRAINT "Home_fk9" FOREIGN KEY ("H9") REFERENCES "Players"("id");


ALTER TABLE "Umpires" ADD CONSTRAINT "Umpires_fk0" FOREIGN KEY ("game_id") REFERENCES "Games"("game_id");
ALTER TABLE "Umpires" ADD CONSTRAINT "Umpires_fk1" FOREIGN KEY ("hp_umpire") REFERENCES "Umpires Info"("id");
ALTER TABLE "Umpires" ADD CONSTRAINT "Umpires_fk2" FOREIGN KEY ("1b_umpire") REFERENCES "Umpires Info"("id");
ALTER TABLE "Umpires" ADD CONSTRAINT "Umpires_fk3" FOREIGN KEY ("2b_umpire") REFERENCES "Umpires Info"("id");
ALTER TABLE "Umpires" ADD CONSTRAINT "Umpires_fk4" FOREIGN KEY ("3b_umpire") REFERENCES "Umpires Info"("id");
ALTER TABLE "Umpires" ADD CONSTRAINT "Umpires_fk5" FOREIGN KEY ("lf_umpire") REFERENCES "Umpires Info"("id");
ALTER TABLE "Umpires" ADD CONSTRAINT "Umpires_fk6" FOREIGN KEY ("rf_umpire") REFERENCES "Umpires Info"("id");

